function whiteSpace(str){
    let result = str.replaceAll(" ", "");
    return result;
}
console.log(whiteSpace("Jagdish,       pagar"));


