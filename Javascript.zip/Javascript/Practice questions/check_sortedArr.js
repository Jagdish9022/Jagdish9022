// function checkarr(arr){
//     if (arr.sort((a,b)=>a-b)==arr) {
//        return true;
//     }else{
//     return false;
//     }
// }
// console.log(checkarr([1,2,3,6,4,5]));

function isorted(arr){
    for (let i = 1; i < arr.length; i++) {
        if (arr[i - 1]> arr[i]) {
            return false
        }
    }
    return true;
}
console.log(isorted([1,2,3,4,5,7,6]));
