function find(str){

        let words = str.split(" ");
        let logestword = "";

        for (let word of words){
            if (word.length > logestword.length ) {
                logestword = word;
            }
            
        }
        return logestword
}  

console.log(find("i am Jagdish fsffghghkjgksjdghsfjkdhgsfdghsfdjghsd Pagar"));
