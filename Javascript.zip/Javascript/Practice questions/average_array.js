function avrage(arr) {
    let sum = arr.reduce((a,b)=>{
        return a+b;
    });
    let total= sum/arr.length;
    return total;
}
console.log(avrage([1,2,3,4,5,,7,8,6]));
