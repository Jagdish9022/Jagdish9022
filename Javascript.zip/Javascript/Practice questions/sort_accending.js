function sort(arr){
    let accending = arr.sort((a,b)=>{
        return a=b;
    })
    return accending;
}
console.log(sort([1,2,56,3,45,]));
