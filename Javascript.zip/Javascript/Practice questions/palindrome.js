function palindrome(str){
 let newstr = "";
 for(let i = str.length-1; i>=0; i--){
    newstr += str[i];
 }
 
 if (newstr == str) {
    console.log(str +"  it's palindrome");
    
 }
 else{
    console.log(str +"  it's not palindrome");
 }
}
palindrome("jagdsih");
