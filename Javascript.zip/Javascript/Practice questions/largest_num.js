function findnum(arr){
    let logestnum = 0;
    for (let i = 0; i < arr.length; i++) {
        if (arr[i]>logestnum) {
            logestnum = arr[i];
        }
        
    }
    return logestnum;
}
console.log(findnum([166,2,3,4,5,56,78]));
