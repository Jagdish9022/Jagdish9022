function sorted(arr1, arr2){
    let merged = arr1.concat(arr2);
    return merged.sort((a,b)=>a-b);
}
let array1 = [1,23,45,3,4,];
let array2 = [5,8,7,6];
console.log(sorted(array1, array2));

