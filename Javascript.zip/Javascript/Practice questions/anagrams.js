function anagram(str1, str2){
    let newstr1 = str1.split("").sort().join("");
    let newstr2 = str2.split("").sort().join("");
    return newstr1 === newstr2? "correct" : "Somthing wrong" ;
}
console.log(anagram("listen" ,"silent"));



