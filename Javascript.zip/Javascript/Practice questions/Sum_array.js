function sum(arr){
 let newarr=   arr.reduce((a,b)=>a+b);
    return newarr;
}
console.log(sum([1,2,3,4,5]));;

function sum2(array){
    let sum1 = 0; 
    for (let i = 0; i <array.length; i++) {
        
        sum1 += array[i];
    }
    return sum1;
}
console.log(sum2([1,2,3,4,5]));
