function findLargest(arr){
    let array = arr.sort((a,b)=> b-a);

    return array[1];
}
console.log(findLargest([1,2,3,8,4,5,6,7,11,12]));
