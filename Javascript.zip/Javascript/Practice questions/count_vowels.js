function findvowel(vowel){
 let vowels = ['a','e','i','o','u']   ;
 let count = 0;

 for (let word of vowel.toLowerCase()){
    if (vowels.includes(word)) {
        count++
    }
 }
 return count;
}
console.log(findvowel("I am jagdish"));
