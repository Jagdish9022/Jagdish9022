// function find_uniquekey(arr){
//     console.log(...new Set(arr));

// }
// find_uniquekey([1,2,2,3,4,5,6,6,7,8]);




function removeDuplicates(arr) {

    const uniqueElements = [];

    for (let i = 0; i < arr.length; i++) {

        if (uniqueElements.indexOf(arr[i]) === -1) {
            uniqueElements.push(arr[i])
        }
    }
    return uniqueElements;
}

console.log(removeDuplicates([1, 2, 3, 4, 4, 5, 6, 6]));