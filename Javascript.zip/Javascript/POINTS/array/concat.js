let array = [1,2,3,4,5,6];
let array2 = [1,2,3,4,5,6];
console.log(array2.concat(array));
