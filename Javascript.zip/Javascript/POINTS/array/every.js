let array = [1,2,3,4,5,6];
console.log(array.every((a)=>a%2==0));

let array1 = [1,2,3,4,5,6];
console.log(array1.every((a)=>a>=0));
