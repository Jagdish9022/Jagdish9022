
let numbers = [4, 2, 5, 1, 3];
console.log(numbers.sort((a, b) =>  b-a));  
