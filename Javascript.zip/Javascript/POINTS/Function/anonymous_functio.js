console.log(function (a,b){
    return a+b;
}(12,23));
