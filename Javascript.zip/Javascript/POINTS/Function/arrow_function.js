let add = (a,b)=>{
    return a+b;
}
console.log(add(12,45));
