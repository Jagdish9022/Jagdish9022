let prompt = require('prompt');

// Example 1
function processUserInput(callback) {
    // Initialize the prompt
    prompt.start();

    // Get the input
    prompt.get(['name'], function (err, result) {
        if (err) {
            console.error(err);
            return;
        }
        callback(result.name);
    });
}

processUserInput(function(name) {
    console.log("Hello, " + name);
});

// Example 2
// function fetchData(url, callback) {
//     // Simulating an API call
//     setTimeout(() => {
//         const data = "API data";
//         callback(data);
//     }, 2000);
// }

// fetchData("https://api.example.com", function(data) {
//     console.log("Received:", data);
// });

// Example 3
// const numbers = [1, 2, 3, 4, 5];
// const doubled = numbers.map(function(number) {
//     return number * 2;
// });

// console.log(doubled); // Output: [2, 4, 6, 8, 10]
