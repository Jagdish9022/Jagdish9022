let prompt = require('prompt-sync');


function processUserInput(callback) {
    let name = prompt("Please enter your name.");
    callback(name);
}

processUserInput(function(name) {
    console.log("Hello, " + name);
});


function fetchData(url, callback) {
    
    setTimeout(() => {
        const data = "API data";
        callback(data);
    }, 2000);
}

fetchData("https://api.example.com", function(data) {
    console.log("Received:", data);
});


const numbers = [1, 2, 3, 4, 5];
const doubled = numbers.map(function(number) {
    return number * 2;
});

console.log(doubled);
