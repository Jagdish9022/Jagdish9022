function display(a,b,operation){
    let result = operation(a,b);
    console.log(result);
}
display(30,6, mul)
function add(a,b){
    return a+b;
}
function sub(a,b){
    return a-b;
}
function mul(a,b){
    return a*b;
}
function div(a,b){
    return a/b;
}