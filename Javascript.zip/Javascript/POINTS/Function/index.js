let prompt = require('prompt-sync')()

console.log("Start");

let nam = setTimeout(()=>{ prompt("enter your name :- ")},3000);
function name(nam) {
    console.log(`hello, ${nam}`);

}
setTimeout(()=>name(nam),5000)

setTimeout(() => {
    console.log('End')
}, 6000);



