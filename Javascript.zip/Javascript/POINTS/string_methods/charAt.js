let str = "jagdish";
console.log(str.charAt(4));
