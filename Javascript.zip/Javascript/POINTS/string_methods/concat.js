let str1 = "jagdish";
let str2 = "pagar";
console.log(str1.concat(" ",str2));
