let str = "jagdish pagar";
console.log(str.at(2));
