try{
    let result = someUndifined +10;
    console.log(result);
    
}
catch(e){
    console.log("message : "+ e.message);
}