try {
    const result = someundefined+100;
    console.log(result);
    
} catch (error) {
    console.log("An error ocured : "+ error.message);
}
finally{
    console.log("finaly exicuted");
    
}l