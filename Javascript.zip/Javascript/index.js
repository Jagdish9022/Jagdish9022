// let str = "babe";
// let b = "";
// for (let i = 0; i <= str.length - 1; i++) {
//     b = str[i] + b
// }
// if (str == b) {
//     console.log("palindrome");

// } else {
//     console.log("not palindrome");

// }
// let a = "bqweab";
// let b = "";
// for (let i = a.length - 1; i >= 0; i--) {
//     b += a[i];
// }
// if (a == b) {
//     console.log("palindrome");

// } else {
//     console.log("not palindrome");

// }

let a = "bab";
let b= a.split("").reverse().join("");
if (a == b) {
    console.log("palindrome");

} else {
    console.log("not palindrome");
}