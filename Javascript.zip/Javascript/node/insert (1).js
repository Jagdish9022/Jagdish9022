const dbconnect = require('./mongo');

const insert = async ()=>{
    const db=await dbconnect();
    const result = await db.insertOne({
        name:"Krushna",age:22, education:"BCA Fail",city:"Daregaon"
    });

    if(result.acknowledged){
        console.log("Zale re ");
    }
    else{
        console.log("kahi tari chukale");
    }
};
insert();
