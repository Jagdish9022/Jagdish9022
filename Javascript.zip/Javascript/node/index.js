
// for (i =1; i<=10; i++){
//     const element  = i ;
// if (element == 5 ) {
//         //console.log("5 is matherchod numer");
//     }
//  console.log(element);
// }

// for(i=0; i<=10; i++){
//     //console.log(`outer loop is ${i}`);
//     for(j=0; j<=10; j++){
//       //  console.log(`inner loop is : ${j} and ${i}`);
//       //console.log(i+ " * " + j + " = " + j*i);
//     }
// }


// const array = ["jagdish","Krushna","Mayur","Rahul"]
// console.log(array.length);
// for (let index = 0; index <= array.length; index++) {
//     const element = array[index];
//     console.log(element);
    
// }

// for(i= 1 ; i<=20; i++){
//     if(i==5){
//         console.log("detected 5");
//         break;
//     }
//     console.log(i);
// }
for(i= 1 ; i<=20; i++){
    if(i==5){
        console.log("detected 5");
        continue;
    }
    console.log(i);
}